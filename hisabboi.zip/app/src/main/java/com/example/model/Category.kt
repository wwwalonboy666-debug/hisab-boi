package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class Category(
    val key: String,
    val nameBn: String,
    val nameEn: String,
    val icon: ImageVector,
    val type: TransactionType,
    val color: Color
)

object CategoryRegistry {
    // Expense Categories
    val FOOD = Category(
        key = "EXP_FOOD",
        nameBn = "খাবার",
        nameEn = "Food & Dining",
        icon = Icons.Default.Restaurant,
        type = TransactionType.EXPENSE,
        color = Color(0xFFE57373)
    )

    val GROCERY = Category(
        key = "EXP_GROCERY",
        nameBn = "বাজার",
        nameEn = "Groceries",
        icon = Icons.Default.ShoppingCart,
        type = TransactionType.EXPENSE,
        color = Color(0xFF81C784)
    )

    val TRANSPORT = Category(
        key = "EXP_TRANSPORT",
        nameBn = "যাতায়াত",
        nameEn = "Transport",
        icon = Icons.Default.DirectionsBus,
        type = TransactionType.EXPENSE,
        color = Color(0xFF64B5F6)
    )

    val SHOPPING = Category(
        key = "EXP_SHOPPING",
        nameBn = "শপিং",
        nameEn = "Shopping",
        icon = Icons.Default.Storefront,
        type = TransactionType.EXPENSE,
        color = Color(0xFFBA68C8)
    )

    val BILLS = Category(
        key = "EXP_BILLS",
        nameBn = "বিল",
        nameEn = "Utility Bills",
        icon = Icons.Default.ReceiptLong,
        type = TransactionType.EXPENSE,
        color = Color(0xFFFFB74D)
    )

    val EDUCATION = Category(
        key = "EXP_EDUCATION",
        nameBn = "শিক্ষা",
        nameEn = "Education",
        icon = Icons.Default.School,
        type = TransactionType.EXPENSE,
        color = Color(0xFF4DB6AC)
    )

    val HEALTHCARE = Category(
        key = "EXP_HEALTHCARE",
        nameBn = "চিকিৎসা",
        nameEn = "Healthcare",
        icon = Icons.Default.LocalHospital,
        type = TransactionType.EXPENSE,
        color = Color(0xFFF06292)
    )

    val ENTERTAINMENT = Category(
        key = "EXP_ENTERTAINMENT",
        nameBn = "বিনোদন",
        nameEn = "Entertainment",
        icon = Icons.Default.Movie,
        type = TransactionType.EXPENSE,
        color = Color(0xFFAED581)
    )

    val OTHER_EXPENSE = Category(
        key = "EXP_OTHER",
        nameBn = "অন্যান্য",
        nameEn = "Other Expense",
        icon = Icons.Default.MoreHoriz,
        type = TransactionType.EXPENSE,
        color = Color(0xFF90A4AE)
    )

    // Income Categories
    val SALARY = Category(
        key = "INC_SALARY",
        nameBn = "বেতন",
        nameEn = "Salary",
        icon = Icons.Default.Payments,
        type = TransactionType.INCOME,
        color = Color(0xFF4CAF50)
    )

    val BUSINESS = Category(
        key = "INC_BUSINESS",
        nameBn = "ব্যবসা",
        nameEn = "Business",
        icon = Icons.Default.Storefront,
        type = TransactionType.INCOME,
        color = Color(0xFF2E7D32)
    )

    val FREELANCING = Category(
        key = "INC_FREELANCING",
        nameBn = "ফ্রিল্যান্সিং",
        nameEn = "Freelancing",
        icon = Icons.Default.Work,
        type = TransactionType.INCOME,
        color = Color(0xFF00897B)
    )

    val GIFT = Category(
        key = "INC_GIFT",
        nameBn = "উপহার",
        nameEn = "Gift",
        icon = Icons.Default.CardGiftcard,
        type = TransactionType.INCOME,
        color = Color(0xFFFF8F00)
    )

    val OTHER_INCOME = Category(
        key = "INC_OTHER",
        nameBn = "অন্যান্য",
        nameEn = "Other Income",
        icon = Icons.Default.MonetizationOn,
        type = TransactionType.INCOME,
        color = Color(0xFF558B2F)
    )

    val expenseCategories = listOf(
        FOOD, GROCERY, TRANSPORT, SHOPPING, BILLS, EDUCATION, HEALTHCARE, ENTERTAINMENT, OTHER_EXPENSE
    )

    val incomeCategories = listOf(
        SALARY, BUSINESS, FREELANCING, GIFT, OTHER_INCOME
    )

    val allCategories = expenseCategories + incomeCategories

    fun getCategory(key: String): Category {
        return allCategories.find { it.key == key } ?: OTHER_EXPENSE
    }
}
