package com.example.data.repository

import com.example.data.HisabBoiDatabase
import com.example.data.entity.AppPreferenceEntity
import com.example.data.entity.BudgetEntity
import com.example.data.entity.SavingsGoalEntity
import com.example.data.entity.TransactionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext

class HisabBoiRepository(private val database: HisabBoiDatabase) {

    private val transactionDao = database.transactionDao()
    private val budgetDao = database.budgetDao()
    private val savingsGoalDao = database.savingsGoalDao()
    private val appPreferenceDao = database.appPreferenceDao()

    // Preferences
    val preferences: Flow<AppPreferenceEntity?> = appPreferenceDao.getPreferences()

    suspend fun ensurePreferencesInitialized() = withContext(Dispatchers.IO) {
        val existing = preferences.firstOrNull()
        if (existing == null) {
            appPreferenceDao.insertOrUpdate(
                AppPreferenceEntity(
                    id = 1,
                    language = "bn",
                    themeMode = "SYSTEM",
                    onboardingCompleted = false,
                    notificationsEnabled = false
                )
            )
        }
    }

    suspend fun setLanguage(lang: String) = withContext(Dispatchers.IO) {
        ensurePreferencesInitialized()
        appPreferenceDao.updateLanguage(lang)
    }

    suspend fun setThemeMode(mode: String) = withContext(Dispatchers.IO) {
        ensurePreferencesInitialized()
        appPreferenceDao.updateThemeMode(mode)
    }

    suspend fun setOnboardingCompleted(completed: Boolean) = withContext(Dispatchers.IO) {
        ensurePreferencesInitialized()
        appPreferenceDao.setOnboardingCompleted(completed)
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) = withContext(Dispatchers.IO) {
        ensurePreferencesInitialized()
        appPreferenceDao.setNotificationsEnabled(enabled)
    }

    // Transactions
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val totalIncome: Flow<Double?> = transactionDao.getTotalIncome()
    val totalExpense: Flow<Double?> = transactionDao.getTotalExpense()

    fun getTransactionsForMonth(startMillis: Long, endMillis: Long): Flow<List<TransactionEntity>> {
        return transactionDao.getTransactionsBetween(startMillis, endMillis)
    }

    fun getRecentTransactions(limit: Int = 5): Flow<List<TransactionEntity>> {
        return transactionDao.getRecentTransactions(limit)
    }

    fun getMonthlyIncome(startMillis: Long, endMillis: Long): Flow<Double?> {
        return transactionDao.getMonthlyIncome(startMillis, endMillis)
    }

    fun getMonthlyExpense(startMillis: Long, endMillis: Long): Flow<Double?> {
        return transactionDao.getMonthlyExpense(startMillis, endMillis)
    }

    fun getTransactionById(id: Long): Flow<TransactionEntity?> {
        return transactionDao.getTransactionById(id)
    }

    suspend fun insertTransaction(transaction: TransactionEntity): Long = withContext(Dispatchers.IO) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransaction(transaction)
    }

    suspend fun deleteTransactionById(id: Long) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransactionById(id)
    }

    // Budget
    fun getBudgetForMonth(monthKey: String): Flow<BudgetEntity?> {
        return budgetDao.getBudgetForMonth(monthKey)
    }

    fun getAllBudgets(): Flow<List<BudgetEntity>> {
        return budgetDao.getAllBudgets()
    }

    suspend fun setBudget(monthKey: String, amount: Double) = withContext(Dispatchers.IO) {
        val budget = BudgetEntity(
            monthKey = monthKey,
            amount = amount,
            updatedAt = System.currentTimeMillis()
        )
        budgetDao.insertOrUpdateBudget(budget)
    }

    suspend fun deleteBudgetForMonth(monthKey: String) = withContext(Dispatchers.IO) {
        budgetDao.deleteBudgetForMonth(monthKey)
    }

    // Savings Goals
    val allSavingsGoals: Flow<List<SavingsGoalEntity>> = savingsGoalDao.getAllSavingsGoals()

    fun getSavingsGoalById(id: Long): Flow<SavingsGoalEntity?> {
        return savingsGoalDao.getSavingsGoalById(id)
    }

    suspend fun insertSavingsGoal(name: String, targetAmount: Double, initialSaved: Double = 0.0): Long = withContext(Dispatchers.IO) {
        val goal = SavingsGoalEntity(
            name = name,
            targetAmount = targetAmount,
            savedAmount = initialSaved.coerceAtLeast(0.0)
        )
        savingsGoalDao.insertSavingsGoal(goal)
    }

    suspend fun updateSavingsGoal(goal: SavingsGoalEntity) = withContext(Dispatchers.IO) {
        savingsGoalDao.updateSavingsGoal(goal)
    }

    suspend fun addSavings(goalId: Long, amount: Double) = withContext(Dispatchers.IO) {
        savingsGoalDao.addSavings(goalId, amount)
    }

    suspend fun deleteSavingsGoalById(id: Long) = withContext(Dispatchers.IO) {
        savingsGoalDao.deleteSavingsGoalById(id)
    }
}
