package com.example.util

import com.example.model.AppLanguage

class Strings(val lang: AppLanguage) {

    // App & Tagline
    val appName = "HisabBoi"
    val tagline = if (lang == AppLanguage.BN) "হিসাব রাখি, জীবনটা গুছিয়ে রাখি।" else "Keep track, keep life organized."

    // Navigation
    val navHome = if (lang == AppLanguage.BN) "Home" else "Home"
    val navTransactions = if (lang == AppLanguage.BN) "হিসাব" else "Transactions"
    val navReports = if (lang == AppLanguage.BN) "রিপোর্ট" else "Reports"
    val navSettings = if (lang == AppLanguage.BN) "Settings" else "Settings"

    // Greetings
    fun greeting(hourOfDay: Int): String {
        return if (lang == AppLanguage.BN) {
            when (hourOfDay) {
                in 5..11 -> "শুভ সকাল 🌿"
                in 12..16 -> "শুভ অপরাহ্ণ 🌿"
                in 17..20 -> "শুভ সন্ধ্যা 🌿"
                else -> "শুভ রাত্রি 🌿"
            }
        } else {
            when (hourOfDay) {
                in 5..11 -> "Good Morning 🌿"
                in 12..16 -> "Good Afternoon 🌿"
                in 17..20 -> "Good Evening 🌿"
                else -> "Good Night 🌿"
            }
        }
    }

    val greetingSub = if (lang == AppLanguage.BN) "আজকের হিসাবটা গুছিয়ে নিই" else "Let's organize today's finances"

    // Home Balance
    val totalBalance = if (lang == AppLanguage.BN) "মোট ব্যালেন্স" else "Total Balance"
    val incomeLabel = if (lang == AppLanguage.BN) "↑ আয়" else "↑ Income"
    val expenseLabel = if (lang == AppLanguage.BN) "↓ খরচ" else "↓ Expense"

    // Quick Actions
    val addExpenseQuick = if (lang == AppLanguage.BN) "＋ খরচ" else "＋ Expense"
    val addIncomeQuick = if (lang == AppLanguage.BN) "＋ আয়" else "＋ Income"

    // Monthly Budget Card
    val monthBudgetTitle = if (lang == AppLanguage.BN) "এই মাসের বাজেট" else "This Month's Budget"
    val setBudgetPrompt = if (lang == AppLanguage.BN) "এই মাসের বাজেট সেট করুন" else "Set this month's budget"
    val setBudgetBtn = if (lang == AppLanguage.BN) "বাজেট সেট করুন" else "Set Budget"
    val editBudgetBtn = if (lang == AppLanguage.BN) "বাজেট পরিবর্তন" else "Edit Budget"
    val removeBudgetBtn = if (lang == AppLanguage.BN) "বাজেট মুছুন" else "Remove Budget"
    val budgetWarning80 = if (lang == AppLanguage.BN) "আপনার বাজেটের বেশিরভাগ ব্যবহার হয়ে গেছে।" else "Most of your budget has been utilized."
    val budgetWarning100 = if (lang == AppLanguage.BN) "এই মাসের বাজেট অতিক্রম হয়েছে।" else "This month's budget has been exceeded."
    val usedLabel = if (lang == AppLanguage.BN) "ব্যবহৃত" else "Used"
    val remainingLabel = if (lang == AppLanguage.BN) "অবশিষ্ট" else "Remaining"

    // Recent Transactions
    val recentTransactionsTitle = if (lang == AppLanguage.BN) "সাম্প্রতিক হিসাব" else "Recent Transactions"
    val viewAll = if (lang == AppLanguage.BN) "সব হিসাব দেখুন" else "View All"
    val emptyTransactionsTitle = if (lang == AppLanguage.BN) "এখনও কোনো হিসাব যোগ করা হয়নি।" else "No transactions recorded yet."
    val emptyTransactionsSub = if (lang == AppLanguage.BN) "আপনার প্রথম আয় বা খরচ যোগ করুন।" else "Add your first income or expense."

    // Add / Edit Transaction
    val addExpenseTitle = if (lang == AppLanguage.BN) "খরচ যোগ করুন" else "Add Expense"
    val addIncomeTitle = if (lang == AppLanguage.BN) "আয় যোগ করুন" else "Add Income"
    val editTransactionTitle = if (lang == AppLanguage.BN) "হিসাব সম্পাদনা" else "Edit Transaction"
    val amountFieldLabel = if (lang == AppLanguage.BN) "পরিমাণ" else "Amount"
    val categoryFieldLabel = if (lang == AppLanguage.BN) "খাত নির্বাচন করুন" else "Select Category"
    val dateFieldLabel = if (lang == AppLanguage.BN) "তারিখ" else "Date"
    val noteFieldLabel = if (lang == AppLanguage.BN) "নোট (ঐচ্ছিক)" else "Note (Optional)"
    val saveExpenseBtn = if (lang == AppLanguage.BN) "খরচ সংরক্ষণ করুন" else "Save Expense"
    val saveIncomeBtn = if (lang == AppLanguage.BN) "আয় সংরক্ষণ করুন" else "Save Income"
    val updateTransactionBtn = if (lang == AppLanguage.BN) "হিসাব আপডেট করুন" else "Update Transaction"
    val invalidAmountError = if (lang == AppLanguage.BN) "দয়া করে সঠিক পরিমাণ লিখুন (০-এর বেশি)" else "Please enter a valid amount (> 0)"
    val savedSuccessToast = if (lang == AppLanguage.BN) "হিসাব সফলভাবে সংরক্ষিত হয়েছে ✓" else "Transaction saved successfully ✓"
    val updatedSuccessToast = if (lang == AppLanguage.BN) "হিসাব আপডেট করা হয়েছে ✓" else "Transaction updated successfully ✓"
    val deletedSuccessToast = if (lang == AppLanguage.BN) "হিসাব মুছে ফেলা হয়েছে" else "Transaction deleted"

    // Transactions Screen
    val allTransactionsTitle = if (lang == AppLanguage.BN) "সব হিসাব" else "All Transactions"
    val searchHint = if (lang == AppLanguage.BN) "হিসাব খুঁজুন (নোট বা খাত)..." else "Search transactions (note or category)..."
    val filterAll = if (lang == AppLanguage.BN) "সব" else "All"
    val filterIncome = if (lang == AppLanguage.BN) "আয়" else "Income"
    val filterExpense = if (lang == AppLanguage.BN) "খরচ" else "Expense"
    val netTotalLabel = if (lang == AppLanguage.BN) "নিট ব্যালেন্স" else "Net Total"
    val deleteConfirmTitle = if (lang == AppLanguage.BN) "হিসাব মুছে ফেলতে চান?" else "Delete this transaction?"
    val deleteConfirmMsg = if (lang == AppLanguage.BN) "এই হিসাবটি স্থায়ীভাবে মুছে যাবে।" else "This record will be permanently deleted."
    val cancelBtn = if (lang == AppLanguage.BN) "বাতিল" else "Cancel"
    val deleteBtn = if (lang == AppLanguage.BN) "মুছে ফেলুন" else "Delete"
    val editBtn = if (lang == AppLanguage.BN) "সম্পাদনা" else "Edit"

    // Reports Screen
    val reportsTitle = if (lang == AppLanguage.BN) "রিপোর্ট ও বিশ্লেষণ" else "Reports & Insights"
    val totalIncomeReport = if (lang == AppLanguage.BN) "মোট আয়" else "Total Income"
    val totalExpenseReport = if (lang == AppLanguage.BN) "মোট খরচ" else "Total Expense"
    val netBalanceReport = if (lang == AppLanguage.BN) "নিট সঞ্চয়" else "Net Savings"
    val categoryBreakdownTitle = if (lang == AppLanguage.BN) "খাতভিত্তিক ব্যয়ের বিবরণ" else "Category Spending Breakdown"
    val financialInsightsTitle = if (lang == AppLanguage.BN) "আর্থিক পর্যালোচনা" else "Financial Insights"
    val emptyReportTitle = if (lang == AppLanguage.BN) "রিপোর্ট দেখানোর মতো পর্যাপ্ত হিসাব নেই।" else "Not enough records to display report."
    val emptyReportSub = if (lang == AppLanguage.BN) "আরও কিছু হিসাব যোগ হলে এখানে আপনার আর্থিক চিত্র দেখা যাবে।" else "Add more transactions to view a detailed financial overview."

    // Savings Screen
    val savingsTitle = if (lang == AppLanguage.BN) "আপনার স্বপ্নের জন্য সঞ্চয় 🌱" else "Save for Your Dreams 🌱"
    val addSavingsGoal = if (lang == AppLanguage.BN) "নতুন সঞ্চয়ের লক্ষ্য" else "New Savings Goal"
    val goalNameLabel = if (lang == AppLanguage.BN) "লক্ষ্যের নাম (যেমন: নতুন ফোন)" else "Goal Name (e.g. New Phone)"
    val targetAmountLabel = if (lang == AppLanguage.BN) "লক্ষ্যের পরিমাণ" else "Target Amount"
    val initialAmountLabel = if (lang == AppLanguage.BN) "বর্তমান জমা (ঐচ্ছিক)" else "Initial Saved (Optional)"
    val addSavingsBtn = if (lang == AppLanguage.BN) "সঞ্চয় যোগ করুন" else "Add Savings"
    val createGoalBtn = if (lang == AppLanguage.BN) "লক্ষ্য তৈরি করুন" else "Create Goal"
    val emptySavingsTitle = if (lang == AppLanguage.BN) "আপনার প্রথম সঞ্চয়ের লক্ষ্য তৈরি করুন 🌱" else "Create your first savings goal 🌱"
    val emptySavingsSub = if (lang == AppLanguage.BN) "ছোট ছোট সঞ্চয় থেকেই বড় স্বপ্ন পূরণ হয়।" else "Small consistent savings build big dreams."
    val targetLabel = if (lang == AppLanguage.BN) "লক্ষ্য" else "Target"
    val savedLabel = if (lang == AppLanguage.BN) "জমেছে" else "Saved"

    // Plant stages
    fun plantStageName(progress: Float): String {
        return if (lang == AppLanguage.BN) {
            when {
                progress >= 1.0f -> "পরিপূর্ণ বৃক্ষ 🌳 (অভিনন্দন!)"
                progress >= 0.75f -> "ফলবান তরু 🪴"
                progress >= 0.50f -> "তরুণ চারা 🌿"
                progress >= 0.25f -> "নবীন কুঁড়ি 🌱"
                else -> "বীজ বোনা হয়েছে 🌰"
            }
        } else {
            when {
                progress >= 1.0f -> "Full Grown Tree 🌳 (Completed!)"
                progress >= 0.75f -> "Thriving Plant 🪴"
                progress >= 0.50f -> "Young Sapling 🌿"
                progress >= 0.25f -> "Sprouting Seedling 🌱"
                else -> "Planted Seed 🌰"
            }
        }
    }

    // Settings Screen
    val settingsTitle = if (lang == AppLanguage.BN) "সেটিংস" else "Settings"
    val appearanceSection = if (lang == AppLanguage.BN) "চেহারা (Appearance)" else "Appearance"
    val themeSystem = if (lang == AppLanguage.BN) "সিস্টেম ডিফল্ট" else "System Default"
    val themeLight = if (lang == AppLanguage.BN) "লাইট মোড" else "Light Mode"
    val themeDark = if (lang == AppLanguage.BN) "ডার্ক মোড" else "Dark Mode"

    val languageSection = if (lang == AppLanguage.BN) "ভাষা (Language)" else "Language"
    val langBn = "বাংলা (Bangla)"
    val langEn = "English"

    val currencySection = if (lang == AppLanguage.BN) "মুদ্রা" else "Currency"
    val currencyDisplay = "বাংলাদেশী টাকা (BDT ৳)"

    val notificationSection = if (lang == AppLanguage.BN) "অনুস্মারক ও নোটিফিকেশন" else "Reminders & Notifications"
    val dailyReminderTitle = if (lang == AppLanguage.BN) "দৈনিক হিসাবের স্মরণিকা" else "Daily Accounting Reminder"
    val dailyReminderSub = if (lang == AppLanguage.BN) "প্রতিদিন রাতে হিসাব লিখে রাখার তাগিদ" else "A peaceful reminder to log expenses each evening"

    val aboutSection = if (lang == AppLanguage.BN) "হিসাববই সম্পর্কে" else "About HisabBoi"
    val privacyTitle = if (lang == AppLanguage.BN) "গোপনীয়তা ও অফলাইন নিরাপত্তা" else "Privacy & Local Offline Data"
    val privacyDetails = if (lang == AppLanguage.BN)
        "আপনার আর্থিক সকল হিসাব সম্পূর্ণভাবে আপনার ডিভাইসেই সংরক্ষিত থাকে। কোনো সার্ভারে আপনার তথ্য পাঠানো হয় না।"
    else
        "All your financial records are stored strictly on your local device. Zero data is sent to external servers."
    val termsTitle = if (lang == AppLanguage.BN) "শর্তাবলী" else "Terms of Use"
    val appVersionLabel = if (lang == AppLanguage.BN) "সংস্করণ" else "Version"

    // Onboarding
    val onb1Title = if (lang == AppLanguage.BN) "सहজে হিসাব রাখুন 🌿" else "Effortless Accounting 🌿"
    val onb1Sub = if (lang == AppLanguage.BN) "আপনার প্রতিদিনের আয় ও খরচ সহজভাবে গুছিয়ে রাখুন।" else "Organize daily income and expenses with peaceful ease."

    val onb2Title = if (lang == AppLanguage.BN) "আপনার বাজেট বুঝুন 📊" else "Understand Your Budget 📊"
    val onb2Sub = if (lang == AppLanguage.BN) "মাসে কোথায় কত খরচ হচ্ছে তা এক নজরে দেখুন।" else "See where your money goes each month at a glance."

    val onb3Title = if (lang == AppLanguage.BN) "আপনার স্বপ্নের জন্য সঞ্চয় করুন 🌱" else "Save for Your Dreams 🌱"
    val onb3Sub = if (lang == AppLanguage.BN) "সঞ্চয়ের লক্ষ্য তৈরি করুন এবং ধীরে ধীরে এগিয়ে যান।" else "Set savings goals and watch them grow like a nurturing plant."

    val onbStartBtn = if (lang == AppLanguage.BN) "শুরু করি →" else "Get Started →"
    val nextBtn = if (lang == AppLanguage.BN) "পরবর্তী" else "Next"
    val skipBtn = if (lang == AppLanguage.BN) "এড়িয়ে যান" else "Skip"
}
