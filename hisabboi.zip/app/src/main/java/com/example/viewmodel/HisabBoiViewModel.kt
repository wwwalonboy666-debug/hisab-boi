package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.entity.AppPreferenceEntity
import com.example.data.entity.BudgetEntity
import com.example.data.entity.SavingsGoalEntity
import com.example.data.entity.TransactionEntity
import com.example.data.repository.HisabBoiRepository
import com.example.model.AppLanguage
import com.example.model.Category
import com.example.model.CategoryRegistry
import com.example.model.ThemeMode
import com.example.model.TransactionType
import com.example.util.DateUtils
import com.example.util.Strings
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class CategorySpend(
    val category: Category,
    val amount: Double,
    val percentage: Float
)

data class MonthBudgetState(
    val budget: BudgetEntity?,
    val budgetAmount: Double,
    val usedAmount: Double,
    val remainingAmount: Double,
    val progress: Float,
    val isNearLimit: Boolean, // >= 80%
    val isOverBudget: Boolean // >= 100%
)

data class ReportState(
    val totalIncome: Double,
    val totalExpense: Double,
    val netBalance: Double,
    val categorySpends: List<CategorySpend>,
    val topCategory: Category?,
    val topCategoryAmount: Double,
    val previousMonthExpense: Double?,
    val expenseDifferencePercentage: Float?, // positive means increased, negative means decreased
    val incomeSpentPercentage: Float?
)

class HisabBoiViewModel(private val repository: HisabBoiRepository) : ViewModel() {

    private val calendar = Calendar.getInstance()
    private val currentYear = calendar.get(Calendar.YEAR)
    private val currentMonthIndex = calendar.get(Calendar.MONTH) // 0-based

    // Selected Month & Year
    private val _selectedYear = MutableStateFlow(currentYear)
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonthIndex = MutableStateFlow(currentMonthIndex)
    val selectedMonthIndex: StateFlow<Int> = _selectedMonthIndex.asStateFlow()

    // Transient UI Message Feedback
    private val _userMessage = MutableSharedFlow<String>()
    val userMessage = _userMessage.asSharedFlow()

    // Preferences
    val preferences: StateFlow<AppPreferenceEntity> = repository.preferences
        .map { it ?: AppPreferenceEntity() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = AppPreferenceEntity()
        )

    val currentLanguage: StateFlow<AppLanguage> = preferences.map { pref ->
        if (pref.language.equals("en", ignoreCase = true)) AppLanguage.EN else AppLanguage.BN
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AppLanguage.BN)

    val currentThemeMode: StateFlow<ThemeMode> = preferences.map { pref ->
        when (pref.themeMode) {
            "LIGHT" -> ThemeMode.LIGHT
            "DARK" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, ThemeMode.SYSTEM)

    val strings: StateFlow<Strings> = currentLanguage.map { Strings(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Strings(AppLanguage.BN))

    // Transactions
    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentTransactions: StateFlow<List<TransactionEntity>> = repository.getRecentTransactions(5)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Overall Balance Summary (All-time)
    val overallIncome: StateFlow<Double> = repository.totalIncome
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val overallExpense: StateFlow<Double> = repository.totalExpense
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val overallBalance: StateFlow<Double> = combine(overallIncome, overallExpense) { inc, exp ->
        inc - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Month-keyed transactions
    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMonthTransactions: StateFlow<List<TransactionEntity>> =
        combine(_selectedYear, _selectedMonthIndex) { year, month ->
            DateUtils.getMonthRangeMillis(year, month)
        }.flatMapLatest { (startMillis, endMillis) ->
            repository.getTransactionsForMonth(startMillis, endMillis)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Monthly Totals
    val selectedMonthIncome: StateFlow<Double> = selectedMonthTransactions.map { list ->
        list.filter { it.type == TransactionType.INCOME.name }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val selectedMonthExpense: StateFlow<Double> = selectedMonthTransactions.map { list ->
        list.filter { it.type == TransactionType.EXPENSE.name }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Budget for Selected Month
    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedMonthBudget: StateFlow<BudgetEntity?> =
        combine(_selectedYear, _selectedMonthIndex) { year, month ->
            DateUtils.toMonthKey(year, month)
        }.flatMapLatest { monthKey ->
            repository.getBudgetForMonth(monthKey)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val budgetState: StateFlow<MonthBudgetState> =
        combine(selectedMonthBudget, selectedMonthExpense) { budget, expense ->
            val budgetAmount = budget?.amount ?: 0.0
            val used = expense
            val remaining = (budgetAmount - used).coerceAtLeast(0.0)
            val progress = if (budgetAmount > 0) (used / budgetAmount).toFloat() else 0f
            MonthBudgetState(
                budget = budget,
                budgetAmount = budgetAmount,
                usedAmount = used,
                remainingAmount = remaining,
                progress = progress,
                isNearLimit = progress >= 0.80f && progress < 1.0f,
                isOverBudget = progress >= 1.0f
            )
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            MonthBudgetState(null, 0.0, 0.0, 0.0, 0f, false, false)
        )

    // Savings Goals
    val allSavingsGoals: StateFlow<List<SavingsGoalEntity>> = repository.allSavingsGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filter State for Transactions Screen
    val searchQuery = MutableStateFlow("")
    val filterType = MutableStateFlow("ALL") // "ALL", "INCOME", "EXPENSE"
    val selectedCategoryKey = MutableStateFlow<String?>(null)

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        selectedMonthTransactions,
        searchQuery,
        filterType,
        selectedCategoryKey
    ) { transactions, query, type, catKey ->
        transactions.filter { tx ->
            val matchesType = when (type) {
                "INCOME" -> tx.type == TransactionType.INCOME.name
                "EXPENSE" -> tx.type == TransactionType.EXPENSE.name
                else -> true
            }
            val matchesCategory = catKey == null || tx.categoryKey == catKey
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                val cat = CategoryRegistry.getCategory(tx.categoryKey)
                tx.note.contains(query, ignoreCase = true) ||
                        cat.nameBn.contains(query, ignoreCase = true) ||
                        cat.nameEn.contains(query, ignoreCase = true)
            }
            matchesType && matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reports State
    @OptIn(ExperimentalCoroutinesApi::class)
    val reportState: StateFlow<ReportState> = combine(
        selectedMonthTransactions,
        selectedMonthIncome,
        selectedMonthExpense,
        _selectedYear,
        _selectedMonthIndex
    ) { transactions, income, expense, year, month ->
        // Calculate prior month range
        val priorCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            add(Calendar.MONTH, -1)
        }
        val priorYear = priorCal.get(Calendar.YEAR)
        val priorMonth = priorCal.get(Calendar.MONTH)
        val priorRange = DateUtils.getMonthRangeMillis(priorYear, priorMonth)

        Triple(transactions, Pair(income, expense), priorRange)
    }.flatMapLatest { (transactions, totals, priorRange) ->
        val (income, expense) = totals
        repository.getMonthlyExpense(priorRange.first, priorRange.second).map { priorExp ->
            // Category breakdowns
            val expenseTxList = transactions.filter { it.type == TransactionType.EXPENSE.name }
            val categoryGrouped = expenseTxList.groupBy { it.categoryKey }
            val spends = categoryGrouped.map { (catKey, list) ->
                val amount = list.sumOf { it.amount }
                val percentage = if (expense > 0) ((amount / expense) * 100).toFloat() else 0f
                CategorySpend(
                    category = CategoryRegistry.getCategory(catKey),
                    amount = amount,
                    percentage = percentage
                )
            }.sortedByDescending { it.amount }

            val topSpend = spends.firstOrNull()
            val net = income - expense

            val diffPercentage = if (priorExp != null && priorExp > 0 && expense > 0) {
                (((expense - priorExp) / priorExp) * 100).toFloat()
            } else null

            val incSpentPct = if (income > 0) {
                ((expense / income) * 100).toFloat()
            } else null

            ReportState(
                totalIncome = income,
                totalExpense = expense,
                netBalance = net,
                categorySpends = spends,
                topCategory = topSpend?.category,
                topCategoryAmount = topSpend?.amount ?: 0.0,
                previousMonthExpense = priorExp,
                expenseDifferencePercentage = diffPercentage,
                incomeSpentPercentage = incSpentPct
            )
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ReportState(0.0, 0.0, 0.0, emptyList(), null, 0.0, null, null, null)
    )

    init {
        viewModelScope.launch {
            repository.ensurePreferencesInitialized()
        }
    }

    // Navigation & Month change
    fun nextMonth() {
        val currentM = _selectedMonthIndex.value
        val currentY = _selectedYear.value
        if (currentM == 11) {
            _selectedYear.value = currentY + 1
            _selectedMonthIndex.value = 0
        } else {
            _selectedMonthIndex.value = currentM + 1
        }
    }

    fun previousMonth() {
        val currentM = _selectedMonthIndex.value
        val currentY = _selectedYear.value
        if (currentM == 0) {
            _selectedYear.value = currentY - 1
            _selectedMonthIndex.value = 11
        } else {
            _selectedMonthIndex.value = currentM - 1
        }
    }

    fun resetToCurrentMonth() {
        val now = Calendar.getInstance()
        _selectedYear.value = now.get(Calendar.YEAR)
        _selectedMonthIndex.value = now.get(Calendar.MONTH)
    }

    // Actions: Transactions
    fun addTransaction(
        type: TransactionType,
        amount: Double,
        categoryKey: String,
        dateMillis: Long,
        note: String
    ) {
        if (amount <= 0) return
        viewModelScope.launch {
            val tx = TransactionEntity(
                type = type.name,
                amount = amount,
                categoryKey = categoryKey,
                dateMillis = dateMillis,
                note = note.trim()
            )
            repository.insertTransaction(tx)
            _userMessage.emit(strings.value.savedSuccessToast)
        }
    }

    fun updateTransaction(
        id: Long,
        type: TransactionType,
        amount: Double,
        categoryKey: String,
        dateMillis: Long,
        note: String
    ) {
        if (amount <= 0) return
        viewModelScope.launch {
            val tx = TransactionEntity(
                id = id,
                type = type.name,
                amount = amount,
                categoryKey = categoryKey,
                dateMillis = dateMillis,
                note = note.trim(),
                updatedAt = System.currentTimeMillis()
            )
            repository.updateTransaction(tx)
            _userMessage.emit(strings.value.updatedSuccessToast)
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            _userMessage.emit(strings.value.deletedSuccessToast)
        }
    }

    // Actions: Budget
    fun setBudget(amount: Double) {
        if (amount <= 0) return
        viewModelScope.launch {
            val monthKey = DateUtils.toMonthKey(_selectedYear.value, _selectedMonthIndex.value)
            repository.setBudget(monthKey, amount)
            _userMessage.emit(strings.value.savedSuccessToast)
        }
    }

    fun deleteBudget() {
        viewModelScope.launch {
            val monthKey = DateUtils.toMonthKey(_selectedYear.value, _selectedMonthIndex.value)
            repository.deleteBudgetForMonth(monthKey)
            _userMessage.emit(strings.value.deletedSuccessToast)
        }
    }

    // Actions: Savings
    fun createSavingsGoal(name: String, targetAmount: Double, initialSaved: Double = 0.0) {
        if (name.isBlank() || targetAmount <= 0) return
        viewModelScope.launch {
            repository.insertSavingsGoal(name.trim(), targetAmount, initialSaved)
            _userMessage.emit(strings.value.savedSuccessToast)
        }
    }

    fun addSavings(goalId: Long, amount: Double) {
        if (amount <= 0) return
        viewModelScope.launch {
            repository.addSavings(goalId, amount)
            _userMessage.emit(strings.value.savedSuccessToast)
        }
    }

    fun updateSavingsGoal(goal: SavingsGoalEntity) {
        viewModelScope.launch {
            repository.updateSavingsGoal(goal)
            _userMessage.emit(strings.value.updatedSuccessToast)
        }
    }

    fun deleteSavingsGoal(id: Long) {
        viewModelScope.launch {
            repository.deleteSavingsGoalById(id)
            _userMessage.emit(strings.value.deletedSuccessToast)
        }
    }

    // Actions: Preferences & Language
    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.setLanguage(language.code)
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.setThemeMode(mode.code)
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            repository.setOnboardingCompleted(true)
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setNotificationsEnabled(enabled)
        }
    }
}
