package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette: Nature x Finance x Peace
// Warm off-white, soft forest green, sage and warm earth
val NatureGreenPrimaryLight = Color(0xFF1B5E3C)
val NatureGreenOnPrimaryLight = Color(0xFFFFFFFF)
val NatureGreenContainerLight = Color(0xFFD3EEDD)
val NatureGreenOnContainerLight = Color(0xFF042113)

val NatureSageSecondaryLight = Color(0xFF426850)
val NatureSageOnSecondaryLight = Color(0xFFFFFFFF)
val NatureSageContainerLight = Color(0xFFE3EDE5)
val NatureSageOnContainerLight = Color(0xFF132A1D)

val NatureEarthTertiaryLight = Color(0xFF7A5C43)
val NatureEarthContainerLight = Color(0xFFF7ECE4)
val NatureEarthOnContainerLight = Color(0xFF2C190D)

val NatureBackgroundLight = Color(0xFFF7FAF7) // Serene warm off-white canvas
val NatureSurfaceLight = Color(0xFFFFFFFF)
val NatureSurfaceVariantLight = Color(0xFFEAF1EB)
val NatureTextPrimaryLight = Color(0xFF15221B)
val NatureTextSecondaryLight = Color(0xFF55665D)
val NatureOutlineLight = Color(0xFFD6E2D9)

// Dark Palette: Deep charcoal / green-black, calming leaf green accents
val NatureGreenPrimaryDark = Color(0xFF62D38E)
val NatureGreenOnPrimaryDark = Color(0xFF04331B)
val NatureGreenContainerDark = Color(0xFF174D2E)
val NatureGreenOnContainerDark = Color(0xFFB5F2CD)

val NatureSageSecondaryDark = Color(0xFF90CCA3)
val NatureSageOnSecondaryDark = Color(0xFF153622)
val NatureSageContainerDark = Color(0xFF264933)
val NatureSageOnContainerDark = Color(0xFFCEECD7)

val NatureEarthTertiaryDark = Color(0xFFDEC3AC)
val NatureEarthContainerDark = Color(0xFF4A3423)
val NatureEarthOnContainerDark = Color(0xFFFCEFE6)

val NatureBackgroundDark = Color(0xFF0F1612) // Deep charcoal green
val NatureSurfaceDark = Color(0xFF17201B) // Elevated dark slate leaf
val NatureSurfaceVariantDark = Color(0xFF1F2B24)
val NatureTextPrimaryDark = Color(0xFFE8F1EC)
val NatureTextSecondaryDark = Color(0xFFA1B3A8)
val NatureOutlineDark = Color(0xFF2D3C33)

// Financial semantic colors (Peaceful, non-aggressive)
val IncomeGreen = Color(0xFF2E7D32)
val IncomeGreenContainerLight = Color(0xFFE8F5E9)
val IncomeGreenContainerDark = Color(0xFF183822)

val ExpenseRose = Color(0xFFC62828)
val ExpenseRoseContainerLight = Color(0xFFFFEBEE)
val ExpenseRoseContainerDark = Color(0xFF401D1F)

val GoldenCoin = Color(0xFFD49E24)
val GoldenCoinLight = Color(0xFFFFF8E1)
